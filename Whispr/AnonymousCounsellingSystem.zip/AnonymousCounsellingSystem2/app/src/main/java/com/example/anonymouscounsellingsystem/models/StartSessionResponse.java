package com.example.anonymouscounsellingsystem.models;

public class StartSessionResponse {
    public boolean success;
    public int     session_id;     // sent by PHP on success
    public boolean reused;         // true if we reused an existing chat
    public String  message;        // non-null on errors
}
