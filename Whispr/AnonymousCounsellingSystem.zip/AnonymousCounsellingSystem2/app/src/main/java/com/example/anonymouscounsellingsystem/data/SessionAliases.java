package com.example.anonymouscounsellingsystem.data;

public class SessionAliases {
    public boolean success;
    public String  client_alias;
    public String  counsellor_alias;
}