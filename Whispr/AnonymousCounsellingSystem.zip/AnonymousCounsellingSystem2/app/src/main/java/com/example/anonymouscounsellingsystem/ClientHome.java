package com.example.anonymouscounsellingsystem;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.anonymouscounsellingsystem.api.ApiClient;
import com.example.anonymouscounsellingsystem.api.ApiService;
import com.example.anonymouscounsellingsystem.models.ProblemsListResponse;
import com.example.anonymouscounsellingsystem.models.StartSessionResponse;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ClientHome extends AppCompatActivity {

    private ApiService api;
    private int userId;           // numeric PK set in onCreate()

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_client_home);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        

        //prefs
        SharedPreferences prefs = getSharedPreferences("AuthPrefs", MODE_PRIVATE);
        userId = prefs.getInt("userId", 0);

        //UI
        ImageButton ibNewChat = findViewById(R.id.ImageButtonNewChat);
        ibNewChat.setOnClickListener(v -> handleNewChat());
    }

    private void handleNewChat() {
        api = ApiClient.getClient().create(ApiService.class);

        String username = getSharedPreferences("AuthPrefs", MODE_PRIVATE)
                .getString("username", "");

        api.getClientProblems(username).enqueue(new Callback<>() {
            @Override
            public void onResponse(@NonNull Call<ProblemsListResponse> call, @NonNull Response<ProblemsListResponse> r) {
                if (!r.isSuccessful() || r.body() == null) {
                    Toast.makeText(ClientHome.this,
                            "Error fetching problems: " + r.code(),
                            Toast.LENGTH_LONG).show();
                    return;
                }
                List<Integer> problems = r.body().getProblems();
                if (problems == null || problems.isEmpty()) {
                    startActivity(new Intent(ClientHome.this, ProblemSelector.class));
                } else {
                    startChat(problems);
                }
            }

            @Override
            public void onFailure(@NonNull Call<ProblemsListResponse> call, @NonNull Throwable t) {
                Toast.makeText(ClientHome.this,
                        "Network error: " + t.getMessage(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    private void startChat(List<Integer> problemIds) {
        api.startSession(userId, problemIds).enqueue(new Callback<>() {
                    @Override
                    public void onResponse(@NonNull Call<StartSessionResponse> c, @NonNull Response<StartSessionResponse> r) {
                        StartSessionResponse body = r.body();
                        if (!r.isSuccessful() || body == null || !body.success) {
                            String msg = (body != null) ? body.message : "Server error " + r.code();
                            Toast.makeText(ClientHome.this, msg, Toast.LENGTH_LONG).show();
                            return;
                        }

                        if (body.reused) {
                            Toast.makeText(ClientHome.this, "You already have an open chat.", Toast.LENGTH_LONG).show();
                        }

                        int sessionId = body.session_id;
                        Intent i = new Intent(ClientHome.this, Chat.class);
                        i.putExtra(Chat.EXTRA_SESSION_ID, sessionId);
                        startActivity(i);
                    }

                    @Override
                    public void onFailure(@NonNull Call<StartSessionResponse> c, @NonNull Throwable t) {
                        Toast.makeText(ClientHome.this, "Network error: " + t.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }

    public void goToInbox(View v) {
        startActivity(new Intent(this, Inbox.class));
    }

    private void clearSession() {
        getSharedPreferences("AuthPrefs", MODE_PRIVATE).edit().clear().apply();
    }

    public void doLogout(View v) {
        clearSession();
        Intent i = new Intent(this, Welcome.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
    }

    public void goToProblemSelector(View v) {
        startActivity(new Intent(this, ProblemSelector.class));
    }
}
