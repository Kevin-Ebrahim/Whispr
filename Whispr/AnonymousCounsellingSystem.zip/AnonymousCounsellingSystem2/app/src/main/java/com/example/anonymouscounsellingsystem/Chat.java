package com.example.anonymouscounsellingsystem;

import static android.view.View.GONE;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.anonymouscounsellingsystem.adapter.ChatAdapter;
import com.example.anonymouscounsellingsystem.api.ApiClient;
import com.example.anonymouscounsellingsystem.api.ApiService;
import com.example.anonymouscounsellingsystem.data.ChatMessage;
import com.example.anonymouscounsellingsystem.data.SendMessageResponse;
import com.example.anonymouscounsellingsystem.data.SessionAliases;
import com.example.anonymouscounsellingsystem.models.GenericResponse;
import com.example.anonymouscounsellingsystem.models.SessionStatusResponse;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Chat extends AppCompatActivity {
    public static final String EXTRA_SESSION_ID = "sessionId";
    // For generating negative‐ID “system” messages
    private final AtomicInteger tempSeq = new AtomicInteger(-1);
    private final java.util.Set<Integer> seen = new java.util.HashSet<>();
    private final Handler h = new Handler(Looper.getMainLooper());
    private RecyclerView rv;
    private EditText et;
    private ImageButton btn;
    private TextView tvUsername;
    private ChatAdapter adapter;
    private ApiService api;
    private Toolbar tbChat;
    private int myId;
    private int sessionId;
    private int lastId = 0;
    private String sessionStatus;
    private boolean sendInProgress = false;
    MenuItem endItem;

    @Override
    protected void onCreate(@Nullable Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_chat);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        myId = getSharedPreferences("AuthPrefs", MODE_PRIVATE).getInt("userId", 0);
        sessionId = getIntent().getIntExtra(EXTRA_SESSION_ID, 0);
        if (sessionId == 0) finish();

        api = ApiClient.getClient().create(ApiService.class);

        rv = findViewById(R.id.RecyclerViewChat);
        et = findViewById(R.id.EditTextMessage);
        btn = findViewById(R.id.ImageButtonSend);
        tvUsername = findViewById(R.id.tvUsername);

        tbChat = findViewById(R.id.toolbarChat);
        setSupportActionBar(tbChat);
        Drawable drawable = ContextCompat.getDrawable(getApplicationContext(), R.drawable.baseline_more_vert_24);
        tbChat.setOverflowIcon(drawable);

        adapter = new ChatAdapter(myId);
        rv.setAdapter(adapter);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setItemAnimator(new DefaultItemAnimator());

        btn.setOnClickListener(this::onSendClicked);

        String myType = getSharedPreferences("AuthPrefs", MODE_PRIVATE).getString("user_type", "");

        api.getSessionAliases(sessionId).enqueue(new Callback<>() {
            @Override
            public void onResponse(@NonNull Call<SessionAliases> call, @NonNull Response<SessionAliases> resp) {
                if (resp.isSuccessful() && resp.body() != null && resp.body().success) {
                    SessionAliases a = resp.body();
                    String nameToShow = myType.equalsIgnoreCase("Client")
                            ? a.counsellor_alias
                            : a.client_alias;
                    tvUsername.setText(nameToShow);
                } else {
                    tvUsername.setText("Unknown");
                }
            }

            @Override
            public void onFailure(@NonNull Call<SessionAliases> call, @NonNull Throwable t) {
                tvUsername.setText("Offline");
            }
        });

        api.getSessionStatus(sessionId).enqueue(new Callback<>() {
            @Override
            public void onResponse(@NonNull Call<SessionStatusResponse> call, @NonNull Response<SessionStatusResponse> resp) {
                if (resp.isSuccessful() && resp.body() != null && resp.body().isSuccess()) {
                    sessionStatus = resp.body().status;
                    if ("ended".equals(sessionStatus)) {
                        onChatEnded();

                    } else {
                        updateButtons();
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<SessionStatusResponse> call, @NonNull Throwable t) {
            }
        });
    }

    private void changeStatusToEnded() {
        api.updateSessionStatus(sessionId, "ended")
                .enqueue(new Callback<>() {
                    @Override
                    public void onResponse(@NonNull Call<GenericResponse> call, @NonNull Response<GenericResponse> resp) {
                        if (resp.isSuccessful() && resp.body() != null) {
                            GenericResponse body = resp.body();
                            if (body.isSuccess()) {
                                sessionStatus = "ended";
                                updateButtons();
                                onChatEnded();
                            } else {
                                Toast.makeText(Chat.this,
                                        "Could not end: " + body.getMessage(),
                                        Toast.LENGTH_LONG).show();
                            }
                        } else {
                            String err = "Server error " + resp.code();
                            Toast.makeText(Chat.this, err, Toast.LENGTH_LONG).show();
                        }
                    }

                    @Override
                    public void onFailure(@NonNull Call<GenericResponse> call, @NonNull Throwable t) {
                        Toast.makeText(Chat.this,
                                "Network error while ending chat: " + t.getMessage(),
                                Toast.LENGTH_LONG).show();
                    }
                });
    }    private final Runnable pollTask = new Runnable() {
        @Override
        public void run() {
            if (sendInProgress) {
                h.postDelayed(pollTask, 300);
                return;
            }
            api.getMessages(sessionId, lastId).enqueue(new Callback<>() {
                @Override
                public void onResponse(@NonNull Call<List<ChatMessage>> call, @NonNull Response<List<ChatMessage>> resp) {
                    if (resp.isSuccessful() && resp.body() != null) {
                        List<ChatMessage> batch = resp.body();
                        if (!batch.isEmpty()) {
                            if (lastId == 0) {
                                List<ChatMessage> initial = new ArrayList<>(batch);
                                adapter.submitList(initial);
                            } else {
                                List<ChatMessage> current = new ArrayList<>(adapter.getCurrentList());
                                current.addAll(batch);
                                adapter.submitList(current);
                            }
                            int max = lastId;
                            for (ChatMessage cm : batch) {
                                if (cm.id > max) max = cm.id;
                            }
                            lastId = max;
                            rv.scrollToPosition(adapter.getItemCount() - 1);
                        }
                    }
                    h.postDelayed(pollTask, 3000);
                }

                @Override
                public void onFailure(@NonNull Call<List<ChatMessage>> call, @NonNull Throwable t) {
                    h.postDelayed(pollTask, 5000);
                }
            });
        }
    };

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.action_end) {
            new androidx.appcompat.app.AlertDialog.Builder(this)
                    .setTitle("End Chat")
                    .setMessage("Are you sure you want to close this chat? You will not be able to send/receive messages anymore.")
                    .setPositiveButton("Yes", (dlg, which) -> changeStatusToEnded())
                    .setNegativeButton("Cancel", null)
                    .show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // sending a message
    private void onSendClicked(View v) {
        String txt = et.getText().toString().trim();
        if (txt.isEmpty()) return;

        ChatMessage m = new ChatMessage();
        m.id = tempSeq.getAndDecrement();
        m.senderId = myId;
        m.text = txt;
        m.sentAt = System.currentTimeMillis();
        addMessage(m);

        et.setText("");
        sendInProgress = true;

        api.sendMessage(sessionId, myId, txt)
                .enqueue(new Callback<>() {
                    @Override
                    public void onResponse(@NonNull Call<SendMessageResponse> call, @NonNull Response<SendMessageResponse> resp) {
                        sendInProgress = false;
                        if (resp.isSuccessful() && resp.body() != null && resp.body().success) {
                            int realId = resp.body().id;
                            seen.remove(m.id);
                            m.id = realId;
                            seen.add(realId);
                            submitFresh(adapter.getCurrentList());
                            lastId = realId;
                        }
                    }

                    @Override
                    public void onFailure(@NonNull Call<SendMessageResponse> call, @NonNull Throwable t) {
                        sendInProgress = false;
                    }
                });
    }    private final Runnable statusPoll = new Runnable() {
        @Override
        public void run() {
            api.getSessionStatus(sessionId).enqueue(new Callback<>() {
                @Override
                public void onResponse(@NonNull Call<SessionStatusResponse> call, @NonNull Response<SessionStatusResponse> resp) {
                    if (resp.isSuccessful() && resp.body() != null && resp.body().isSuccess()) {
                        String newStatus = resp.body().status;
                        if (!newStatus.equals(sessionStatus)) {
                            sessionStatus = newStatus;
                            if ("ended".equals(sessionStatus)) {
                                onChatEnded();
                            } else {
                                updateButtons();
                            }
                        }
                    }
                    h.postDelayed(statusPoll, 5000);
                }

                @Override
                public void onFailure(@NonNull Call<SessionStatusResponse> call, @NonNull Throwable t) {
                    h.postDelayed(statusPoll, 8000);
                }
            });
        }
    };

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        endItem = menu.findItem(R.id.action_end);
        // Set initial visibility based on sessionStatus:
        updateButtons();
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        sendInProgress = false;
        h.post(pollTask);
        h.post(statusPoll);
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(pollTask);
        h.removeCallbacks(statusPoll);
    }

    private void onChatEnded() {
        et.setVisibility(GONE);
        btn.setVisibility(GONE);

        Toast.makeText(Chat.this, "Chat closed.", Toast.LENGTH_SHORT).show();
    }

    private void updateButtons() {
        // Only hide/show if onCreateOptionsMenu has already run
        if (endItem != null) {
            endItem.setVisible("in_progress".equals(sessionStatus));
            endItem.setEnabled("in_progress".equals(sessionStatus));
        }
    }

    // extra methods
    public void goToInbox(View v) {
        startActivity(new Intent(this, Inbox.class));
    }

    private void submitFresh(List<ChatMessage> list) {
        adapter.submitList(new ArrayList<>(list));
    }

    private List<ChatMessage> appendOne(List<ChatMessage> old, ChatMessage extra) {
        List<ChatMessage> n = new ArrayList<>(old);
        n.add(extra);
        return n;
    }

    private void addMessage(ChatMessage cm) {
        if (seen.add(cm.id)) {
            submitFresh(appendOne(adapter.getCurrentList(), cm));
        }
    }
}
