package com.example.anonymouscounsellingsystem.adapter;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.example.anonymouscounsellingsystem.R;
import com.example.anonymouscounsellingsystem.data.ChatMessage;

public class ChatAdapter extends ListAdapter<ChatMessage, ChatAdapter.VH> {

    private static final int VIEW_MINE   = 1;
    private static final int VIEW_THEIRS = 2;

    private final int myId;

    public ChatAdapter(int myId) {
        super(DIFF);
        this.myId = myId;
    }

    private static final DiffUtil.ItemCallback<ChatMessage> DIFF =
            new DiffUtil.ItemCallback<>() {
                @Override public boolean areItemsTheSame(@NonNull ChatMessage a, @NonNull ChatMessage b) {
                    return a.id == b.id;
                }
                @Override public boolean areContentsTheSame(@NonNull ChatMessage a, @NonNull ChatMessage b) {
                    return a.text.equals(b.text) && a.senderId == b.senderId;
                }
            };

    // Get which layout?
    @Override public int getItemViewType(int position) {
        return getItem(position).senderId == myId ? VIEW_MINE : VIEW_THEIRS;
    }

    // inflate
    @NonNull
    @Override public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        int layout = (viewType == VIEW_MINE)
                ? R.layout.senderchat_bubble
                : R.layout.receiverchat_bubble;
        View v = LayoutInflater.from(parent.getContext()).inflate(layout, parent, false);
        return new VH(v);
    }

    private static final java.text.SimpleDateFormat HHMM = new java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault());
    // bind
    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        ChatMessage m = getItem(pos);
        Log.d("ADAPTER_BIND", "Position " + pos + " → \"" + m.text + "\" (id=" + m.id + ")");
        h.msg.setText(m.text);

        String t = HHMM.format(new java.util.Date(m.sentAt));
        h.time.setText(t);
    }

    static class VH extends RecyclerView.ViewHolder {
        final TextView msg;
        final TextView time;
        VH(View root) {
            super(root);
            msg = root.findViewById(R.id.tvMessage); // adjust to your id
            time = root.findViewById(R.id.tvTime);
        }
    }
}