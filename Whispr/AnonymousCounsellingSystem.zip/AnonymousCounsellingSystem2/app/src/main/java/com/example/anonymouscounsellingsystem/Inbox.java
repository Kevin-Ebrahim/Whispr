package com.example.anonymouscounsellingsystem;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.anonymouscounsellingsystem.adapter.InboxAdapter;
import com.example.anonymouscounsellingsystem.api.ApiClient;
import com.example.anonymouscounsellingsystem.api.ApiService;
import com.example.anonymouscounsellingsystem.data.InboxItem;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Inbox extends AppCompatActivity {
    private InboxAdapter adapter;

    private ApiService api;
    private int userId;
    private String userType;

    @Override
    protected void onCreate(@Nullable Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_inbox);   // make sure layout exists

        

        // who am I?
        userId = getSharedPreferences("AuthPrefs", MODE_PRIVATE).getInt("userId", 0);
        userType = getSharedPreferences("AuthPrefs", MODE_PRIVATE).getString("user_type", "");   // case matches PHP side

        // UI setup
        RecyclerView rv = findViewById(R.id.rvInbox);

        adapter = new InboxAdapter();
        adapter.setOnClick(this::openChat);
        rv.setAdapter(adapter);
        rv.setLayoutManager(new LinearLayoutManager(this));

        // Retrofit
        api = ApiClient.getClient().create(ApiService.class);

        loadInbox();   // initial fetch

        ImageButton back = findViewById(R.id.btnBack);
        back.setOnClickListener(v -> {
            if (userType.equalsIgnoreCase("Client"))
                goToClientHome(v);
            else
                goToCounsellorHome(v);
        });
    }

    // fetch list from server
    private void loadInbox() {
        api.getInbox(userId, userType).enqueue(new Callback<>() {
            @Override
            public void onResponse(@NonNull Call<List<InboxItem>> c, @NonNull Response<List<InboxItem>> r) {
                if (r.isSuccessful() && r.body() != null) {
                    adapter.submitList(r.body());
                } else {
                    Toast.makeText(Inbox.this,"Failed to load inbox", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(@NonNull Call<List<InboxItem>> c, @NonNull Throwable t) {
                Toast.makeText(Inbox.this,"Network error: " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    // open chat screen when a row is tapped
    private void openChat(InboxItem item) {
        Intent i = new Intent(this, Chat.class);
        i.putExtra(Chat.EXTRA_SESSION_ID, item.sessionId);
        startActivity(i);
    }


    public void goToCounsellorHome(View v) {
        startActivity(new Intent(this, CounsellorHome.class));
    }

    public void goToClientHome(View v) {
        startActivity(new Intent(this, ClientHome.class));
    }
}