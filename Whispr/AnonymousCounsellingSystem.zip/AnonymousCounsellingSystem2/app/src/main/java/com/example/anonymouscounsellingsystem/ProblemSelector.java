package com.example.anonymouscounsellingsystem;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.anonymouscounsellingsystem.api.ApiClient;
import com.example.anonymouscounsellingsystem.api.ApiService;
import com.example.anonymouscounsellingsystem.models.ClientProblemsResponse;
import com.example.anonymouscounsellingsystem.models.CounsellorProblemsResponse;
import com.example.anonymouscounsellingsystem.models.ProblemsListResponse;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProblemSelector extends AppCompatActivity {

    private ListView lvProblems;
    private String[] problems;                     // reference array
    private ApiService api;
    private String  username;
    private String  role;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_problem_selector);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        // prefs + api
        SharedPreferences prefs = getSharedPreferences("AuthPrefs", MODE_PRIVATE);
        username = prefs.getString("username", "");
        role     = prefs.getString("user_type", "");
        api      = ApiClient.getClient().create(ApiService.class);

        // ListView setup
        lvProblems = findViewById(R.id.listViewProblems);
        problems   = getResources().getStringArray(R.array.problems_array);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_list_item_multiple_choice, problems);
        lvProblems.setAdapter(adapter);
        lvProblems.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);

        fetchPreviouslySelectedProblems();

        // submit button
        Button btn = findViewById(R.id.buttonSubmit);
        btn.setOnClickListener(v -> handleSubmit());


        Button back = findViewById(R.id.buttonBack);
        back.setOnClickListener(v -> {
            if (role.equalsIgnoreCase("Client"))
                goToClientHome(v);
            else
                goToCounsellorHome(v);
        });

    }

    private void fetchPreviouslySelectedProblems() {
        if ("Client".equalsIgnoreCase(role)) {
            api.getClientProblems(username).enqueue(new Callback<>() {
                @Override
                public void onResponse(@NonNull Call<ProblemsListResponse> c, @NonNull Response<ProblemsListResponse> r) {
                    if (r.isSuccessful() && r.body() != null)
                        tickChoices(r.body().getProblems());
                }

                @Override
                public void onFailure(@NonNull Call<ProblemsListResponse> c, @NonNull Throwable t) {
                }
            });
        } else {  // counsellor
            api.getCounsellorProblems(username).enqueue(new Callback<>() {
                @Override
                public void onResponse(@NonNull Call<CounsellorProblemsResponse> c, @NonNull Response<CounsellorProblemsResponse> r) {
                    if (r.isSuccessful() && r.body() != null)
                        tickChoices(r.body().getProblems());
                }

                @Override
                public void onFailure(@NonNull Call<CounsellorProblemsResponse> c, @NonNull Throwable t) {
                }
            });
        }
    }

    private void tickChoices(List<Integer> ids) {
        if (ids == null) return;
        for (int id : ids) {
            int pos = id - 1;                        // convert to 0-based index
            if (pos >= 0 && pos < lvProblems.getCount()) {
                lvProblems.setItemChecked(pos, true);
            }
        }
    }

    private void handleSubmit() {
        SparseBooleanArray checked = lvProblems.getCheckedItemPositions();
        List<String> selectedIds   = new ArrayList<>();

        for (int i = 0; i < problems.length; i++) {
            if (checked.get(i)) selectedIds.add(String.valueOf(i + 1));  // 1-based
        }

        String csv  = TextUtils.join(",", selectedIds);
        int    cnt  = selectedIds.size();

        Toast.makeText(this, "You picked " + cnt + " problem(s)", Toast.LENGTH_SHORT).show();

        if ("Client".equalsIgnoreCase(role)) {
            api.submitClientProblems(username, csv).enqueue(new Callback<>() {
                        @Override
                        public void onResponse(@NonNull Call<ClientProblemsResponse> c, @NonNull Response<ClientProblemsResponse> r) {
                            String msg = (r.isSuccessful() && r.body() != null) ? r.body().getMessage() : "Server error " + r.code();
                            Toast.makeText(ProblemSelector.this, msg, Toast.LENGTH_LONG).show();
                        }

                        @Override
                        public void onFailure(@NonNull Call<ClientProblemsResponse> c, @NonNull Throwable t) {
                            Toast.makeText(ProblemSelector.this, "Network error: " + t.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
        } else {
            api.submitCounsellorProblems(username, csv).enqueue(new Callback<>() {
                        @Override
                        public void onResponse(@NonNull Call<CounsellorProblemsResponse> c, @NonNull Response<CounsellorProblemsResponse> r) {
                            String msg = (r.isSuccessful() && r.body() != null)
                                    ? r.body().getMessage()
                                    : "Server error " + r.code();
                            Toast.makeText(ProblemSelector.this, msg, Toast.LENGTH_LONG).show();
                        }

                        @Override
                        public void onFailure(@NonNull Call<CounsellorProblemsResponse> c, @NonNull Throwable t) {
                            Toast.makeText(ProblemSelector.this,
                                    "Network error: " + t.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
        }
    }

    public void goToClientHome(View v) {
        startActivity(new Intent(this, ClientHome.class));
    }

    public void goToCounsellorHome(View v) {
        startActivity(new Intent(this, CounsellorHome.class));
    }
}
