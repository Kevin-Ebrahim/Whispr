package com.example.anonymouscounsellingsystem.data;

public class SendMessageResponse {
    public boolean success;
    public int  id;       // the real DB id assigned by send_message.php
}