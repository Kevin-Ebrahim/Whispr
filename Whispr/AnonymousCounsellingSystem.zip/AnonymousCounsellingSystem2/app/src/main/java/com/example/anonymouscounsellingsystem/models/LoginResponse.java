package com.example.anonymouscounsellingsystem.models;

import com.google.gson.annotations.SerializedName;

public class LoginResponse {
    private boolean success;
    private String message;
    @SerializedName("user_type")
    private String user_type;

    @SerializedName("user_id")
    private int user_id;

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }

    public String getUserType() {
        return user_type;
    };

    public int getUserId() {
        return user_id;
    }
}
