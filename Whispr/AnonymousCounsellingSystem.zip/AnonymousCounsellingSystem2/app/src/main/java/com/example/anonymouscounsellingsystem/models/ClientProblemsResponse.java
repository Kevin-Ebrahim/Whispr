package com.example.anonymouscounsellingsystem.models;

import java.util.List;

public class ClientProblemsResponse {
    private boolean success;
    private String message;
    private List<Integer> problems;
    public boolean isSuccess() {
        return success;
    }
    public String getMessage() {
        return message;
    }
}
