package com.example.anonymouscounsellingsystem;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.anonymouscounsellingsystem.api.ApiClient;
import com.example.anonymouscounsellingsystem.api.ApiService;
import com.example.anonymouscounsellingsystem.models.LoginResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Login extends AppCompatActivity {
    private EditText editUsername, editPassword;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        Button buttonLogin = findViewById(R.id.buttonLogin);

        buttonLogin.setOnClickListener(v -> attemptLogin());
    }

    public void goToWelcome(View v) {
        startActivity(new Intent(this, Welcome.class));
    }

    public void attemptLogin() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Username and password required", Toast.LENGTH_SHORT).show();
            return;
        }

        ApiService api = ApiClient.getClient().create(ApiService.class);
        api.login(username, password).enqueue(new Callback<>() {
            @Override
            public void onResponse(@NonNull Call<LoginResponse> call, @NonNull Response<LoginResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    LoginResponse body = response.body();
                    Toast.makeText(Login.this, body.getMessage(), Toast.LENGTH_LONG).show();
                    if (body.isSuccess()) {
                        SharedPreferences prefs = getSharedPreferences("AuthPrefs", MODE_PRIVATE);
                        prefs.edit()
                                .putString("username", username)
                                .putString("user_type", body.getUserType())
                                .putInt   ("userId",   body.getUserId())
                                .apply();

                        new Handler(Looper.getMainLooper()).postDelayed(() -> {
                            String role = body.getUserType();
                            Intent i;

                            if ("Client".equalsIgnoreCase(role)) {
                                i = new Intent(Login.this, ClientHome.class);
                            }
                            else {
                                i = new Intent(Login.this, CounsellorHome.class);
                            }
                            startActivity(i);
                            finish();
                        }, 2000);
                    }
                }
                else {
                    Toast.makeText(Login.this, "Server error: " + response.code(), Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(@NonNull Call<LoginResponse> call, @NonNull Throwable t) {
                Toast.makeText(Login.this, "Network error: " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}