package com.example.anonymouscounsellingsystem.data;

import com.google.gson.annotations.SerializedName;

public class ChatMessage {
    public int    id;        // DB auto-increment
    @SerializedName("sender_id")
    public int    senderId;  // whoever sent it (client or counsellor)
    @SerializedName("message_text")
    public String text;      // message body
    @SerializedName("sent_ms")
    public long   sentAt;    // epoch millis (UNIX ms)
    // No-arg constructor
    public ChatMessage() {}
}
