package com.example.anonymouscounsellingsystem.models;

import com.google.gson.annotations.SerializedName;

public class UpdateStatusResponse {
    @SerializedName("success")
    private boolean success;

    @SerializedName("message")
    private String message;

    // This matches the "endTime" field returned by the PHP endpoint
    @SerializedName("endTime")
    private String endTime;

    // No-argument constructor
    public UpdateStatusResponse() { }

    // Getters
    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }

    public String getEndTime() {
        return endTime;
    }

    // Setters
    public void setSuccess(boolean success) {
        this.success = success;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
}