package com.example.anonymouscounsellingsystem.api;

import com.example.anonymouscounsellingsystem.data.ChatMessage;
import com.example.anonymouscounsellingsystem.data.InboxItem;
import com.example.anonymouscounsellingsystem.data.SendMessageResponse;
import com.example.anonymouscounsellingsystem.data.SessionAliases;
import com.example.anonymouscounsellingsystem.models.ClientProblemsResponse;
import com.example.anonymouscounsellingsystem.models.CounsellorProblemsResponse;
import com.example.anonymouscounsellingsystem.models.GenericResponse;
import com.example.anonymouscounsellingsystem.models.LoginResponse;
import com.example.anonymouscounsellingsystem.models.ProblemsListResponse;
import com.example.anonymouscounsellingsystem.models.RegisterResponse;
import com.example.anonymouscounsellingsystem.models.SessionStatusResponse;
import com.example.anonymouscounsellingsystem.models.StartSessionResponse;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ApiService {
    @FormUrlEncoded
    @POST("register.php")
    Call<RegisterResponse> register(
            @Field("username") String username,
            @Field("password") String password,
            @Field("user_type") String user_type);

    @FormUrlEncoded
    @POST("login.php")
    Call<LoginResponse> login(
            @Field("username") String username,
            @Field("password") String password
    );

    @FormUrlEncoded
    @POST("insert_client_problems.php")
    Call<ClientProblemsResponse> submitClientProblems(
            @Field("username") String username,
            @Field("problemIds") String problemIdsCsv
    );

    @FormUrlEncoded
    @POST("insert_counsellor_problems.php")
    Call<CounsellorProblemsResponse> submitCounsellorProblems(
            @Field("username") String username,
            @Field("problemIds") String problemIdCsv
    );

    @FormUrlEncoded
    @POST("get_client_problems.php")
    Call<ProblemsListResponse> getClientProblems(
            @Field("username") String username
    );

    @FormUrlEncoded
    @POST("get_counsellor_problems.php")
    Call<CounsellorProblemsResponse> getCounsellorProblems(
            @Field("username") String username
    );

    @FormUrlEncoded
    @POST("get_messages.php")
    Call<List<ChatMessage>> getMessages(
            @Field("sessionId") int sessionId,
            @Field("lastId")    int lastId   // 0 on first call
    );

    @FormUrlEncoded
    @POST("send_message.php")
    Call<SendMessageResponse> sendMessage(
            @Field("sessionId") int sessionId,
            @Field("senderId")  int senderId,
            @Field("text")      String text
    );

    @FormUrlEncoded
    @POST("get_session_aliases.php")
    Call<SessionAliases> getSessionAliases(
            @Field("sessionId") int sessionId
    );

    @FormUrlEncoded
    @POST("get_user_inbox.php")
    Call<List<InboxItem>> getInbox(
            @Field("userId")   int    userId,
            @Field("userType") String userType    // "Client" or "Counsellor"
    );

    @FormUrlEncoded
    @POST("start_session.php")
    Call<StartSessionResponse> startSession(
            @Field("clientId")       int   clientId,
            @Field("problemIds[]") List<Integer> problemIds   // PHP reads it as array
    );

    @FormUrlEncoded
    @POST("update_session_status.php")
    Call<GenericResponse> updateSessionStatus(
            @Field("sessionId")    int    sessionId,
            @Field("newStatus")    String newStatus
    );

    @FormUrlEncoded
    @POST("get_session_status.php")
    Call<SessionStatusResponse> getSessionStatus(
            @Field("sessionId") int sessionId
    );
}