package com.example.anonymouscounsellingsystem.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.example.anonymouscounsellingsystem.R;
import com.example.anonymouscounsellingsystem.data.InboxItem;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class InboxAdapter extends ListAdapter<InboxItem, InboxAdapter.VH> {
    public interface OnClick { void open(InboxItem item); }
    private OnClick listener;
    public void setOnClick(OnClick l) { this.listener = l; }

    public InboxAdapter() { super(DIFF); }

    private static final DiffUtil.ItemCallback<InboxItem> DIFF =
            new DiffUtil.ItemCallback<>() {
                @Override public boolean areItemsTheSame(@NonNull InboxItem a, @NonNull InboxItem b) {
                    return a.sessionId == b.sessionId;
                }
                @Override public boolean areContentsTheSame(@NonNull InboxItem a, @NonNull InboxItem b) {
                    return a.lastTime == b.lastTime && a.lastText.equals(b.lastText);
                }
            };

    // inflate
    @NonNull
    @Override public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater
                .from(parent.getContext())
                .inflate(R.layout.inbox_bubble, parent, false);
        return new VH(v);
    }

    private static final SimpleDateFormat HHMM =
            new SimpleDateFormat("HH:mm", Locale.getDefault());

    // bind
    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        InboxItem it = getItem(pos);
        h.alias.setText(it.alias);
        h.preview.setText(it.lastText);
        h.time.setText(it.lastTime == 0
                ? ""
                : HHMM.format(new Date(it.lastTime)));

        h.itemView.setOnClickListener(v -> {
            if (listener != null) listener.open(it);
        });
    }

    // view-holder
    static class VH extends RecyclerView.ViewHolder {
        final TextView alias;
        final TextView preview;
        final TextView time;
        VH(View root) {
            super(root);
            alias   = root.findViewById(R.id.tvName);
            preview = root.findViewById(R.id.tvLastText);
            time    = root.findViewById(R.id.tvTime);
        }
    }
}
