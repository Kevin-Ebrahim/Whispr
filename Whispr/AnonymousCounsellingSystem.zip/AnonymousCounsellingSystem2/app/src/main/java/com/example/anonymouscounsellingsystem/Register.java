package com.example.anonymouscounsellingsystem;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.anonymouscounsellingsystem.api.ApiClient;
import com.example.anonymouscounsellingsystem.api.ApiService;
import com.example.anonymouscounsellingsystem.models.RegisterResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Register extends AppCompatActivity {
    private EditText editUsername, editPassword;
    private Spinner spinnerUserType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        spinnerUserType = findViewById(R.id.spinnerUserType);
        Button buttonRegister = findViewById(R.id.buttonRegister);

        buttonRegister.setOnClickListener(v -> attemptRegister());
    }

    public void goToWelcome(View v) {
        startActivity(new Intent(this, Welcome.class));
    }

    private void attemptRegister() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString().trim();
        int pos = spinnerUserType.getSelectedItemPosition();
        String user_type = "";
        if (pos > 0) {
            user_type = spinnerUserType.getSelectedItem().toString();
        }

        if (username.isEmpty() || password.isEmpty() || user_type.isEmpty()) {
            Toast.makeText(this, "Please complete all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        ApiService api = ApiClient.getClient().create(ApiService.class);
        Call<RegisterResponse> call = api.register(username, password, user_type);
        call.enqueue(new Callback<>() {
            @Override
            public void onResponse(@NonNull Call<RegisterResponse> call, @NonNull Response<RegisterResponse> response) {
                RegisterResponse body = response.body();
                if (response.isSuccessful() && body != null) {
                    String message = body.getMessage();
                    Toast.makeText(Register.this, message, Toast.LENGTH_LONG).show();

                    if (body.isSuccess()) {
                        new Handler(Looper.getMainLooper()).postDelayed(() -> finish(), 2000);
                    } else {
                        Toast.makeText(Register.this, message, Toast.LENGTH_LONG).show();
                        editUsername.requestFocus();
                        editUsername.setSelection(editUsername.getText().length());
                        //Show Keyboard
                        InputMethodManager imm = (InputMethodManager)
                                Register.this.getSystemService(Context.INPUT_METHOD_SERVICE);
                        if (imm != null) {
                            imm.showSoftInput(editUsername, InputMethodManager.SHOW_IMPLICIT);
                        }
                    }
                } else {
                    Toast.makeText(Register.this, "Server error: " + response.code(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(@NonNull Call<RegisterResponse> call, @NonNull Throwable t) {
                Toast.makeText(Register.this, "Network error: " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}