package com.example.anonymouscounsellingsystem.data;

import com.google.gson.annotations.SerializedName;

public class InboxItem {
    @SerializedName("session_id")
    public int    sessionId;
    @SerializedName("display_alias")
    public String alias;
    @SerializedName("last_text")
    public String lastText;
    @SerializedName("last_time")
    public long   lastTime;
}