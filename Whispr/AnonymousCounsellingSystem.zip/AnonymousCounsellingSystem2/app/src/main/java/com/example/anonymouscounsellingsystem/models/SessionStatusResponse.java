package com.example.anonymouscounsellingsystem.models;

public class SessionStatusResponse {
    private boolean success;
    public String status;
    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return status;
    }
}